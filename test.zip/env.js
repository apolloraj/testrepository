var configure = function () {
    this.setDefaultTimeout(60 * 500);
};

module.exports = configure;